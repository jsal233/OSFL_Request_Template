1. place the store # on the input file
2. make sure you are connected via vpn
3. execute OSFL_Request_Temp.exe